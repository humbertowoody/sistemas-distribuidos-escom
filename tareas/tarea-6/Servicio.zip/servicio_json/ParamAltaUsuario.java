/*
  Carlos Pineda Guerrero, abril 2023
*/

package servicio_json;

public class ParamAltaUsuario 
{
  Usuario usuario;
}
